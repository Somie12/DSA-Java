public class Deposit {
    
}
